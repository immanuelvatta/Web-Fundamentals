console.log("page loaded...");

function playVideo(elements){
    elements.play();
    elements.muted = true;


}

function pauseVideo(elements){
    elements.pause();
}