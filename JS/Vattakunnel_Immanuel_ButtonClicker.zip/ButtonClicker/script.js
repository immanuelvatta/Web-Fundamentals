function sessionStatus(status){
    if(status.innerText=="Login"){
        status.innerText="Logout";
    }
}

function alertLikes(){
    alert("Ninja was liked");
}

function removeButton(button){
    button.remove();
}